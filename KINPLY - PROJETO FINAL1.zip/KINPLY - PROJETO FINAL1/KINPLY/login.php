<!-- 
    <?php 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Crie uma conexão com o banco de dados
    $conn = new mysqli('localhost', 'root', 'stephanyc0574**', 'Senai');

    // Verifique a conexão
    if ($conn->connect_error) {
        die("Conexão com o banco de dados falhou: " . $conn->connect_error);
    }
}
?>
 -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="" method="">

    </form>

</body>
</html>