<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Kinply</title>
    <link rel="stylesheet" href="homepage.css">
</head>
<body>

    <header>
            
        <h1>Kinply</h1>

        <ul>
            <li><a href="">Início</a></li>
            <li><a href="">Contato</a></li>
            <li><a href="">Sobre</a></li>
        </ul>

        </header>

            
    <section class="sectionHome">

       

        <div class="center">
            <h3>Efetue o login :)</h3>
           
        <div class="containlogin">
            <a href="LOGINPROFESSOR.php" class="bbuu">Docente</a>
            <a href="loogi.php" class="bbuu">Aluno</a>
        </div>

        </div>
       

    

    </section>
</body>
</html>